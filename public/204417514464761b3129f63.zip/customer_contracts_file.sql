

CREATE TABLE `customer_contracts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customers_id` int(11) NOT NULL,
  `service_master_id` int(11) NOT NULL,
  `charges` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `free_services_contract` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `minimum_km` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `extracharges_km` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_terms` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contract_pdf` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



INSERT INTO customer_contracts (`id`, `customers_id`, `service_master_id`, `charges`, `free_services_contract`, `minimum_km`, `extracharges_km`, `payment_terms`, `contract_pdf`, `remark`, `is_active`, `created_at`, `updated_at`) VALUES 
('1','36','1','200','Yes','20','2','NEW TERM','uploads/customer/contracts/55QmidN1gPDhrG6KN7IZnzAQiNkYTOVfZutO9eVp.png','','1','2022-04-20 06:29:00','2022-04-20 06:37:36') ,
