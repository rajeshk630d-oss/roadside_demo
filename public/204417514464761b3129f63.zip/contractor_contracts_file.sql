

CREATE TABLE `contractor_contracts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contractor_master_id` int(11) NOT NULL,
  `service_master_id` int(11) NOT NULL,
  `charges` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `minimum_km` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `extracharges_km` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_terms` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contract_pdf` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



INSERT INTO contractor_contracts (`id`, `contractor_master_id`, `service_master_id`, `charges`, `minimum_km`, `extracharges_km`, `payment_terms`, `contract_pdf`, `remark`, `is_active`, `created_at`, `updated_at`) VALUES 
('1','1','2','10','50','1','30','uploads/2019-04/hospital-panel.docx','','1','2019-04-24 16:44:38','') ,
('2','12','8','20','5','2','test payment terms','uploads/contracts/bH0gBkh8NYUKqMTXl54Ge1Jh15WwxPDeW8NWDoHY.png','','0','2022-04-18 06:14:11','2022-04-18 06:26:32') ,
