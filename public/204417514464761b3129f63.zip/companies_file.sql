

CREATE TABLE `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address_line1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address_line2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telephone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `vat_no` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cr_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



INSERT INTO companies (`id`, `name`, `address_line1`, `address_line2`, `address_line3`, `address_line4`, `telephone`, `vat_no`, `email`, `logo`, `cr_no`, `remark`, `is_active`, `created_at`, `updated_at`) VALUES 
('1','AAA LLC','Post Box 107, Ataiba','Postal Code 130','Athaiba','Sultanate of Oman','24605555','1100047467','saidi0533@gmail.com','uploads/users/profile/R7XhbDTqRECGvhkbUtWDrSrOo7uHS567GUSj2IM6.jpg','1639781','','1','2019-03-17 17:11:39','2022-10-10 11:56:57') ,
