

CREATE TABLE `contractor_vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contractor_master_id` int(11) NOT NULL,
  `vehicle_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vehicle_brand_master_id` int(11) NOT NULL,
  `vehicle_type_master_id` int(11) NOT NULL,
  `vehicle_registration_type_master_id` int(11) NOT NULL,
  `model_year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `engine_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `chassis_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `v_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registration_expiry_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `insurance_company` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `insurance_expiry_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



INSERT INTO contractor_vehicles (`id`, `contractor_master_id`, `vehicle_no`, `vehicle_brand_master_id`, `vehicle_type_master_id`, `vehicle_registration_type_master_id`, `model_year`, `engine_no`, `chassis_no`, `v_no`, `registration_expiry_date`, `insurance_company`, `insurance_expiry_date`, `remark`, `is_active`, `created_at`, `updated_at`) VALUES 
('1','1','000000000000','1','1','1','2019','000000','00000','00000','2019-03-31','COMPANY','2019-03-20','','1','2019-03-17 05:35:08','') ,
('2','10','AP35LZ75988','5','4','5','2000','9865431654987','987654321654987','564445','2022-12-12','company','2022-01-01','','1','2022-04-19 06:38:52','2022-04-19 06:51:05') ,
